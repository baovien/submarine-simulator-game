#include "../Include/Core/app.h"

Machine machine;
bool quitGame = false;

int main() {

    App app;

    app.run();

    return 0;
}
